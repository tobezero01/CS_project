﻿namespace Bai_thuc_hanh_1.Models
{
    public enum Branch
    {
        IT,BE,CE,EE
    }
}
