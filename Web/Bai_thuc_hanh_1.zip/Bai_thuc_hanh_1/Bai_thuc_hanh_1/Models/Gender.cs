﻿namespace Bai_thuc_hanh_1.Models
{
    public enum Gender
    {
        Male,
        Female
    }
}
